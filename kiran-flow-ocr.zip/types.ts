
export enum ProcessingStatus {
  IDLE = 'IDLE',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface OCRLine {
  lineNumber: number;
  text: string;
  confidence: number;
}

export interface OCRResult {
  fileName: string;
  pageNumber: number;
  lines: OCRLine[];
  structuredRows?: Record<string, any>[]; // New: List of objects representing organized rows
  tables?: any[][][]; 
  formData?: Record<string, string>;
  overallConfidence: number;
  status: 'success' | 'failed';
  errorMessage?: string;
}

export interface FileBatch {
  id: string;
  file: File;
  previewUrl: string;
  result?: OCRResult;
  status: 'pending' | 'processing' | 'done' | 'error';
}

export interface AppState {
  batches: FileBatch[];
  isProcessing: boolean;
  totalProcessed: number;
}
