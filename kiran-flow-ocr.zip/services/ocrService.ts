
import { GoogleGenAI, Type } from "@google/genai";
import { OCRResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const OCR_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    structuredRows: {
      type: Type.ARRAY,
      description: "A list of records where each record corresponds to one row in the image (e.g., one company entry).",
      items: {
        type: Type.OBJECT,
        properties: {
          companyName: { type: Type.STRING, description: "The name of the company or entity" },
          rapNetId: { type: Type.STRING, description: "The RapNet ID or unique identifier" },
          country: { type: Type.STRING, description: "The country name" },
          city: { type: Type.STRING, description: "The city name" },
          state: { type: Type.STRING, description: "The state or district name" },
          companyType: { type: Type.STRING, description: "The type of company (e.g., Dealer, Manufacturer)" },
          memberYears: { type: Type.STRING, description: "Years of membership" },
          rating: { type: Type.STRING, description: "The rating or score" }
        },
        description: "An object representing a single row of data from the document."
      }
    },
    lines: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          lineNumber: { type: Type.INTEGER },
          text: { type: Type.STRING },
          confidence: { type: Type.NUMBER }
        },
        required: ["lineNumber", "text", "confidence"]
      }
    },
    tables: {
      type: Type.ARRAY,
      description: "Extracted tables as 2D arrays (rows of columns) if they don't fit the structuredRows format.",
      items: {
        type: Type.ARRAY,
        items: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    },
    formData: {
      type: Type.ARRAY,
      description: "Extracted form fields like Name, Date, ID as key-value pairs.",
      items: {
        type: Type.OBJECT,
        properties: {
          key: { type: Type.STRING },
          value: { type: Type.STRING }
        },
        required: ["key", "value"]
      }
    },
    detectedLanguage: { type: Type.STRING },
    overallConfidence: { type: Type.NUMBER }
  },
  required: ["overallConfidence"]
};

export async function performOCR(file: File, fileName: string, language: string = "Auto"): Promise<OCRResult> {
  try {
    const base64Data = await fileToBase64(file);
    const mimeType = file.type || 'image/jpeg';

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          },
          {
            text: `Analyze this document/image and extract the information into a structured table format. 
            
            Target: Identify the rows of data (like a company directory or product list).
            Expected Columns to map to JSON keys:
            - 'companyName': The first column (e.g. P.T Palora Industries Ltd.)
            - 'rapNetId': The second column (e.g. 106100)
            - 'country': The third column (e.g. ISRAEL)
            - 'city': The fourth column (e.g. Ramat Gan)
            - 'state': The fifth column (e.g. Tel Aviv District)
            - 'companyType': The sixth column (e.g. Diamond Dealer/Broker)
            - 'memberYears': The seventh column (e.g. 8)
            - 'rating': The eighth column (e.g. -)
            
            Instructions:
            1. For every entry in the list, create a JSON object in the 'structuredRows' array.
            2. Match the visual values to these specific keys. 
            3. If a value is missing for a column, leave it as an empty string.
            4. If the image headers vary slightly, still use these 8 keys to map the corresponding data.
            5. Provide raw 'lines' as a secondary backup.
            
            Format the output strictly according to the provided JSON schema.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: OCR_SCHEMA
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI model");

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (parseError) {
      console.error("JSON Parse Error for file:", fileName, text);
      throw new Error("Failed to parse AI response as valid JSON structure.");
    }
    
    const lines = parsed.lines || [];
    const structuredRows = parsed.structuredRows || [];
    
    // Log low confidence lines for quality monitoring
    const lowConfidenceLines = lines.filter((l: any) => l.confidence < 0.5);
    if (lowConfidenceLines.length > 0) {
      console.warn(`[OCR Quality Alert] ${fileName}: Detected ${lowConfidenceLines.length} low-confidence lines.`);
    }

    const formData: Record<string, string> = {};
    if (Array.isArray(parsed.formData)) {
      parsed.formData.forEach((item: { key: string; value: string }) => {
        if (item.key) formData[item.key] = item.value;
      });
    }

    return {
      fileName,
      pageNumber: 1,
      lines: lines,
      structuredRows: structuredRows,
      tables: parsed.tables,
      formData: formData,
      overallConfidence: parsed.overallConfidence || 0.9,
      status: 'success'
    };
  } catch (error: any) {
    console.error(`OCR Extraction Failure [${fileName}]:`, error);
    
    let message = 'Unknown extraction error';
    let detailedError = "";
    
    if (error && typeof error === 'object') {
       detailedError = error.message || JSON.stringify(error);
    } else {
       detailedError = String(error);
    }

    if (detailedError.includes("429")) {
      message = "Rate limit exceeded. Please slow down.";
    } else if (detailedError.includes("safety")) {
      message = "Content blocked by safety filters.";
    } else if (detailedError.includes("400") || detailedError.includes("INVALID_ARGUMENT")) {
      message = "API Schema Error: The request format was rejected by the model.";
    } else if (detailedError) {
      message = detailedError;
    }
    
    return {
      fileName,
      pageNumber: 1,
      lines: [],
      overallConfidence: 0,
      status: 'failed',
      errorMessage: message
    };
  }
}

async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64String = result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = error => reject(error);
  });
}
