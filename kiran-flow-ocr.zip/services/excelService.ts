
import * as XLSX from 'xlsx';
import { OCRResult } from '../types';

export function exportToExcel(results: OCRResult[]) {
  const wb = XLSX.utils.book_new();

  // 1. Primary Sheet: Organized Data (Structured Rows)
  // This handles the "one line per record" requirement
  const structuredData = results.flatMap(res => res.structuredRows || []);

  if (structuredData.length > 0) {
    const wsStructured = XLSX.utils.json_to_sheet(structuredData);
    
    // Auto-width logic for structured data
    const maxWidths = structuredData.reduce((acc: any, row) => {
      Object.keys(row).forEach((key, i) => {
        const val = row[key]?.toString() || "";
        acc[i] = Math.max(acc[i] || key.length + 2, val.length + 2);
      });
      return acc;
    }, []);
    wsStructured['!cols'] = maxWidths.map((w: number) => ({ wch: Math.min(w, 50) }));
    
    XLSX.utils.book_append_sheet(wb, wsStructured, "Organized Data");
  }

  // 2. Raw Text Sheet (Fallback)
  const masterData = results.flatMap(res => 
    res.lines.map(line => ({
      'Line No': line.lineNumber,
      'Detected Text': line.text,
      'Confidence': (line.confidence * 100).toFixed(2) + '%'
    }))
  );

  if (masterData.length > 0) {
    const wsMaster = XLSX.utils.json_to_sheet(masterData);
    XLSX.utils.book_append_sheet(wb, wsMaster, "Raw Text Fallback");
  }

  // 3. Tables Sheet (if any extra tables were detected)
  const tableData: any[] = [];
  results.forEach(res => {
    if (res.tables && res.tables.length > 0) {
      res.tables.forEach((table) => {
        table.forEach(row => {
          tableData.push(row);
        });
        tableData.push({}); // Empty row separator
      });
    }
  });

  if (tableData.length > 0) {
    const wsTables = XLSX.utils.json_to_sheet(tableData, { skipHeader: true });
    XLSX.utils.book_append_sheet(wb, wsTables, "Additional Tables");
  }

  // 4. Errors Sheet
  const errorData = results
    .filter(res => res.status === 'failed')
    .map(res => ({
      'File': res.fileName,
      'Error Message': res.errorMessage
    }));

  if (errorData.length > 0) {
    const wsErrors = XLSX.utils.json_to_sheet(errorData);
    XLSX.utils.book_append_sheet(wb, wsErrors, "Errors Log");
  }

  // Finalize and Download
  XLSX.writeFile(wb, `KiranFlow_Structured_Data_${new Date().getTime()}.xlsx`);
}
