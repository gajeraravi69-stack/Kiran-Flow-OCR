
import React, { useState, useMemo, useRef } from 'react';
import { 
  FileUp, 
  FileText, 
  Download, 
  Trash2, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  FileSpreadsheet,
  LayoutGrid,
  Info,
  RefreshCcw,
  Globe
} from 'lucide-react';
import { FileBatch, OCRResult } from './types';
import { performOCR } from './services/ocrService';
import { exportToExcel } from './services/excelService';

// Reduced concurrency to 5 to be more respectful of API rate limits (RPM)
// while still providing significant speed-up over sequential processing.
const CONCURRENCY_LIMIT = 5;

const KiranLogo = () => (
  <div className="flex flex-col items-center">
    <div className="flex items-center gap-6 mb-2">
      <div className="relative w-14 h-14 flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible drop-shadow-sm">
          {/* Stylized K Symbol matching user image */}
          <path 
            d="M0 65 L95 0 L95 62 Z" 
            fill="#005596" 
          />
          <path 
            d="M0 65 L48 98 L0 98 Z" 
            fill="#8c8c8c" 
          />
        </svg>
      </div>
      <div className="flex flex-col items-start leading-none">
        <h1 className="text-5xl font-light tracking-[0.3em] text-[#004a80] lowercase">kiran</h1>
      </div>
    </div>
    <div className="flex items-center gap-3 w-full max-w-[280px]">
      <div className="h-[1px] flex-1 bg-slate-200"></div>
      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.5em] whitespace-nowrap">Flow OCR</span>
      <div className="h-[1px] flex-1 bg-slate-200"></div>
    </div>
  </div>
);

export default function App() {
  const [batches, setBatches] = useState<FileBatch[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("Auto");

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newBatches: FileBatch[] = Array.from(files).map((file: File) => ({
      id: Math.random().toString(36).substring(7),
      file,
      previewUrl: URL.createObjectURL(file),
      status: 'pending'
    }));

    setBatches(prev => [...prev, ...newBatches]);
  };

  const removeBatch = (id: string) => {
    setBatches(prev => {
      const batch = prev.find(b => b.id === id);
      if (batch) URL.revokeObjectURL(batch.previewUrl);
      return prev.filter(b => b.id !== id);
    });
  };

  const clearAll = () => {
    batches.forEach(b => URL.revokeObjectURL(b.previewUrl));
    setBatches([]);
    setIsProcessing(false);
  };

  const processBatch = async () => {
    if (batches.length === 0 || isProcessing) return;
    
    setIsProcessing(true);
    const pendingBatches = batches.filter(b => b.status === 'pending' || b.status === 'error');
    
    let currentIndex = 0;
    while (currentIndex < pendingBatches.length) {
      const chunk = pendingBatches.slice(currentIndex, currentIndex + CONCURRENCY_LIMIT);
      
      await Promise.all(chunk.map(async (batch) => {
        setBatches(prev => prev.map(b => 
          b.id === batch.id ? { ...b, status: 'processing' } : b
        ));

        try {
          const result = await performOCR(batch.file, batch.file.name, selectedLanguage);
          setBatches(prev => prev.map(b => 
            b.id === batch.id ? { 
              ...b, 
              status: result.status === 'success' ? 'done' : 'error', 
              result 
            } : b
          ));
        } catch (error) {
          setBatches(prev => prev.map(b => 
            b.id === batch.id ? { ...b, status: 'error' } : b
          ));
        }
      }));

      currentIndex += CONCURRENCY_LIMIT;
      
      // Add a small delay between chunks to prevent hitting burst rate limits
      if (currentIndex < pendingBatches.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    setIsProcessing(false);
  };

  const retryFailed = () => {
    setBatches(prev => prev.map(b => 
      b.status === 'error' ? { ...b, status: 'pending' } : b
    ));
    setTimeout(processBatch, 0);
  };

  const stats = useMemo(() => {
    const total = batches.length;
    const completed = batches.filter(b => b.status === 'done').length;
    const failed = batches.filter(b => b.status === 'error').length;
    const pending = batches.filter(b => b.status === 'pending' || b.status === 'processing').length;
    const progress = total > 0 ? (completed / total) * 100 : 0;
    return { total, completed, failed, pending, progress };
  }, [batches]);

  const handleExport = () => {
    const results = batches
      .filter(b => b.status === 'done' && b.result)
      .map(b => b.result as OCRResult);
    
    if (results.length === 0) return;
    exportToExcel(results);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <header className="mb-12 text-center flex flex-col items-center">
        <KiranLogo />
        <p className="mt-6 text-slate-500 text-lg max-w-xl font-medium">Bulk data extraction optimized for directories and lists. Clean, structured, organized.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6">
          <div className="glass p-6 rounded-3xl shadow-sm border border-slate-200">
            <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <FileUp className="w-5 h-5 text-blue-600" />
              Source Folder
            </h2>
            
            <label className="group relative flex flex-col items-center justify-center w-full h-44 border-2 border-dashed border-slate-200 rounded-2xl cursor-pointer hover:border-blue-500 hover:bg-blue-50/50 transition-all duration-300">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <FileText className="w-12 h-12 text-slate-300 group-hover:text-blue-500 mb-3 transition-colors" />
                <p className="text-sm text-slate-600 px-6 text-center leading-relaxed">
                  <span className="font-bold text-blue-600">Click to Select</span> or drop images/PDFs
                </p>
                <p className="text-[10px] text-slate-400 mt-2 uppercase tracking-widest font-black">Organized Table Extraction</p>
              </div>
              <input 
                type="file" 
                className="hidden" 
                multiple 
                accept="image/*,application/pdf" 
                onChange={handleFileUpload}
                disabled={isProcessing}
              />
            </label>

            <div className="mt-6">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 flex items-center gap-1">
                <Globe className="w-3 h-3" />
                Language
              </label>
              <select 
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                disabled={isProcessing}
              >
                <option value="Auto">Auto Detect</option>
                <option value="English">English</option>
                <option value="Hindi">Indian (Hindi/Tamil/etc)</option>
              </select>
            </div>

            <div className="mt-8 space-y-3">
              <button
                onClick={processBatch}
                disabled={isProcessing || batches.length === 0 || stats.pending === 0}
                className={`w-full py-4 px-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] ${
                  isProcessing || batches.length === 0 || stats.pending === 0
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'
                    : 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-100'
                }`}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analyzing {stats.completed}/{stats.total}
                  </>
                ) : (
                  <>
                    <RefreshCcw className="w-5 h-5" />
                    Start Extraction
                  </>
                )}
              </button>

              <button
                onClick={handleExport}
                disabled={isProcessing || stats.completed === 0}
                className={`w-full py-4 px-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
                  stats.completed === 0
                    ? 'bg-slate-50 text-slate-300 cursor-not-allowed'
                    : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-100'
                }`}
              >
                <Download className="w-5 h-5" />
                Download Excel
              </button>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={clearAll}
                  disabled={isProcessing || batches.length === 0}
                  className="flex-1 py-2.5 text-xs font-bold text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all border border-transparent hover:border-rose-100"
                >
                  Clear All
                </button>
              </div>
            </div>
          </div>

          {batches.length > 0 && (
            <div className="glass p-6 rounded-3xl shadow-sm border border-slate-200">
              <div className="flex justify-between items-end mb-4">
                <div>
                  <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Job Progress</h3>
                  <p className="text-3xl font-black text-slate-800">{Math.round(stats.progress)}%</p>
                </div>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-blue-600 h-full transition-all duration-1000 ease-out"
                  style={{ width: `${stats.progress}%` }}
                />
              </div>
            </div>
          )}
          
          <div className="p-5 bg-blue-50/50 rounded-2xl border border-blue-100 flex gap-4">
            <Info className="w-6 h-6 text-blue-500 shrink-0" />
            <p className="text-xs text-blue-800 leading-relaxed font-medium">
              <strong>Smart Rows:</strong> Our engine detects columns and organizes data line-by-line automatically. Perfect for directories, invoices, and registration lists.
            </p>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <LayoutGrid className="w-5 h-5 text-blue-600" />
              File Status
            </h2>
          </div>

          <div className="space-y-3 max-h-[80vh] overflow-y-auto pr-2 custom-scrollbar pb-10">
            {batches.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-32 bg-white rounded-[2rem] border-2 border-dashed border-slate-100">
                <div className="bg-slate-50 p-8 rounded-full mb-6">
                   <FileSpreadsheet className="w-16 h-16 text-slate-200" />
                </div>
                <p className="text-slate-400 font-bold text-lg">No files added</p>
              </div>
            ) : (
              batches.map((batch) => (
                <div 
                  key={batch.id} 
                  className={`glass group p-4 rounded-[1.5rem] border transition-all duration-300 ${
                    batch.status === 'processing' 
                      ? 'border-blue-400 bg-blue-50/20 ring-4 ring-blue-50/30' 
                      : batch.status === 'error'
                      ? 'border-rose-200 bg-rose-50/20'
                      : 'border-slate-100 hover:border-slate-300 shadow-sm hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center gap-5">
                    <div className="relative w-14 h-14 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                      {batch.file.type === 'application/pdf' ? (
                        <div className="w-full h-full flex items-center justify-center bg-rose-50">
                           <FileText className="w-6 h-6 text-rose-500" />
                        </div>
                      ) : (
                        <img 
                          src={batch.previewUrl} 
                          alt="Preview" 
                          className="w-full h-full object-cover" 
                        />
                      )}
                      {batch.status === 'processing' && (
                        <div className="absolute inset-0 bg-blue-600/50 flex items-center justify-center">
                          <Loader2 className="w-6 h-6 text-white animate-spin" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1.5">
                        <h3 className="text-sm font-bold text-slate-800 truncate">
                          {batch.file.name}
                        </h3>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {batch.status === 'pending' && <span className="text-[10px] text-slate-400 font-black uppercase tracking-[0.1em]">Pending</span>}
                        {batch.status === 'processing' && <span className="text-[10px] text-blue-600 font-black uppercase tracking-[0.1em]">Extracting Structured Data...</span>}
                        {batch.status === 'done' && (
                          <span className="text-[10px] text-emerald-600 font-black uppercase tracking-[0.1em] flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5" /> 
                            Ready
                          </span>
                        )}
                        {batch.status === 'error' && (
                          <span className="text-[10px] text-rose-600 font-black uppercase tracking-[0.1em] flex items-center gap-2">
                            <AlertCircle className="w-3.5 h-3.5" /> 
                            Error
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {batch.status === 'done' && batch.result && (
                        <div className="hidden sm:flex flex-col items-end px-3 py-1.5 bg-emerald-50/50 border border-emerald-100 rounded-xl">
                           <span className="text-[8px] text-emerald-400 uppercase font-black tracking-widest">Records Found</span>
                           <span className="text-xs font-black text-emerald-700">{batch.result.structuredRows?.length || 0}</span>
                        </div>
                      )}
                      
                      <button 
                        onClick={() => removeBatch(batch.id)}
                        disabled={isProcessing && batch.status === 'processing'}
                        className="p-3 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 20px; }
      `}</style>
    </div>
  );
}
